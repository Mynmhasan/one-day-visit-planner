<?php
// One-time installer: creates the database, tables, sample places and default admin accounts.
require 'config.php';
$seed = json_decode(<<<'SEEDJSON'
[
 {
  "name": "Kalmunai Coastal Area",
  "category": "Beach & Coast",
  "description": "Coastal scenery and seaside views in the Kalmunai area. Check local access and conditions before visiting.",
  "location": "Kalmunai coastal area, Eastern Province, Sri Lanka",
  "hours": "Verify locally before visiting",
  "image": "ella.jpg",
  "tips": "Avoid rough seas and follow local safety advice.",
  "lat": 7.415,
  "lng": 81.842
 },
 {
  "name": "Kalmunai Lagoon View",
  "category": "Nature & Lagoon",
  "description": "A place to appreciate the lagoon environment and local fishing life where public access is available.",
  "location": "Kalmunai area, Eastern Province, Sri Lanka",
  "hours": "Daylight visits recommended; verify access",
  "image": "whale.jpg",
  "tips": "Respect fishing activity and do not enter private property.",
  "lat": 7.426,
  "lng": 81.825
 },
 {
  "name": "Kalmunai Main Market Area",
  "category": "Shopping & Market",
  "description": "Explore local shops and market streets to experience everyday community life.",
  "location": "Town centre, Kalmunai, Sri Lanka",
  "hours": "Varies by shop; verify locally",
  "image": "yala.jpg",
  "tips": "Visit during daytime and be considerate when photographing people.",
  "lat": 7.412,
  "lng": 81.816
 },
 {
  "name": "Local Restaurants in Kalmunai",
  "category": "Food & Restaurant",
  "description": "Discover local food and seafood options around Kalmunai. Individual menus and opening times vary.",
  "location": "Kalmunai town, Sri Lanka",
  "hours": "Varies by restaurant",
  "image": "galle.jpg",
  "tips": "Confirm opening hours and dietary requirements directly with the restaurant.",
  "lat": 7.411,
  "lng": 81.819
 },
 {
  "name": "Kalmunai Religious Sites",
  "category": "Religious & Heritage",
  "description": "Learn about local religious and cultural heritage. Visit only places that are open to visitors.",
  "location": "Kalmunai, Eastern Province, Sri Lanka",
  "hours": "Check with the site before visiting",
  "image": "perahera.jpg",
  "tips": "Dress respectfully and follow site-specific visitor guidance.",
  "lat": 7.414,
  "lng": 81.813
 },
 {
  "name": "Sainthamaruthu Coastal Area",
  "category": "Beach & Coast",
  "description": "Explore the coastal environment in the nearby Sainthamaruthu area.",
  "location": "Sainthamaruthu, Ampara District, Sri Lanka",
  "hours": "Verify local access",
  "image": "mirissa.jpg",
  "tips": "Keep the beach clean and observe sea conditions.",
  "lat": 7.399,
  "lng": 81.838
 },
 {
  "name": "Maruthamunai Local Area",
  "category": "Culture & Local Life",
  "description": "Discover local community life and traditional craft-related activity where publicly accessible.",
  "location": "Maruthamunai, Ampara District, Sri Lanka",
  "hours": "Varies by business or location",
  "image": "drums.jpg",
  "tips": "Ask permission before photographing people or workplaces.",
  "lat": 7.421,
  "lng": 81.824
 },
 {
  "name": "Periyaneelavanai Coastal Area",
  "category": "Beach & Coast",
  "description": "A nearby coastal locality suitable for exploring the eastern shoreline where access is permitted.",
  "location": "Periyaneelavanai, Ampara District, Sri Lanka",
  "hours": "Verify locally",
  "image": "hero.jpg",
  "tips": "Check transport options and weather before travelling.",
  "lat": 7.355,
  "lng": 81.835
 },
 {
  "name": "Local Green Spaces",
  "category": "Parks & Recreation",
  "description": "Look for accessible public outdoor spaces around Kalmunai for a short break during a day visit.",
  "location": "Kalmunai area, Eastern Province, Sri Lanka",
  "hours": "Verify site access and hours",
  "image": "clean.jpg",
  "tips": "Carry drinking water and take all rubbish with you.",
  "lat": 7.413,
  "lng": 81.82
 },
 {
  "name": "Kalmunai Community & Heritage",
  "category": "Culture & Local Life",
  "description": "Explore public community spaces and local heritage in the Kalmunai area.",
  "location": "Kalmunai, Eastern Province, Sri Lanka",
  "hours": "Depends on the location",
  "image": "mission.jpg",
  "tips": "Confirm the exact venue and any visitor restrictions before your trip.",
  "lat": 7.416,
  "lng": 81.817
 }
]
SEEDJSON, true);
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4');
    $pdo->exec('USE `' . DB_NAME . '`');
    $pdo->exec('CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL UNIQUE)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS places(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, category_id INT NOT NULL,
        description TEXT, location VARCHAR(200) NOT NULL, lat DECIMAL(9,6) NOT NULL, lng DECIMAL(9,6) NOT NULL,
        hours VARCHAR(150), image VARCHAR(150) DEFAULT "hero.jpg", tips TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id))');
    $pdo->exec('CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(30) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL, role ENUM("admin","super_admin") NOT NULL DEFAULT "admin", created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE,
        phone VARCHAR(25), password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)');
    if (!$pdo->query('SELECT COUNT(*) FROM places')->fetchColumn()) {
        foreach ($seed as $p) {
            $pdo->prepare('INSERT IGNORE INTO categories(name) VALUES(?)')->execute([$p['category']]);
            $st = $pdo->prepare('SELECT id FROM categories WHERE name=?'); $st->execute([$p['category']]);
            $pdo->prepare('INSERT INTO places(name,category_id,description,location,lat,lng,hours,image,tips) VALUES(?,?,?,?,?,?,?,?,?)')
                ->execute([$p['name'], $st->fetchColumn(), $p['description'], $p['location'], $p['lat'], $p['lng'], $p['hours'], $p['image'], $p['tips']]);
        }
    }
    if (!$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn()) {
        $ins = $pdo->prepare('INSERT INTO admins(username,password_hash,role) VALUES(?,?,?)');
        $ins->execute(['superadmin', password_hash('SuperAdmin@123', PASSWORD_DEFAULT), 'super_admin']);
        $ins->execute(['admin', password_hash('Admin@123', PASSWORD_DEFAULT), 'admin']);
    }
    echo '<h2>Setup complete &#9989;</h2><p>Super admin: <b>superadmin / SuperAdmin@123</b><br>Admin: <b>admin / Admin@123</b></p>
          <p><a href="index.html">Open website</a> | <a href="admin/login.php">Admin login</a></p><p>Delete setup.php after setup.</p>';
} catch (Throwable $ex) {
    echo '<h2>Setup failed</h2><p>Make sure Apache and MySQL are running in XAMPP.</p><pre>' . e($ex->getMessage()) . '</pre>';
}
