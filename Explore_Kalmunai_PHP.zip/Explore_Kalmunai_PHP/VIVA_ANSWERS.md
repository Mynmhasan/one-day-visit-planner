# Viva answers (PHP/MySQL version)
1. Frontend: HTML5, CSS3, JavaScript (fetch). Backend: PHP 8 + MySQL (PDO). Server: XAMPP (Apache).
2. Components: reusable JS functions buildNav(), buildFooter(), placeCard(); PHP admin header (_header.php).
3. Reusable: placeCard(p) builds one card; used on Home (3 places) and Places (all/filtered).
4. loadPlaces(): fetch('api/places.php') -> JSON -> PLACES array -> render functions.
5. config.php db(): new PDO('mysql:host=localhost;dbname=explore_kalmunai', 'root', '') with exceptions on.
6. Maps: embedded iframe https://maps.google.com/maps?q=lat,lng&output=embed + Google Maps links (no API key).
7. GPS: navigator.geolocation.getCurrentPosition() in useMyLocation(); needs permission and localhost/HTTPS.
8. APIs: my own JSON API (api/places.php, api/auth.php) + browser Geolocation API + Google Maps URLs/embed.
9. Route: dist() haversine; optimiseRoute() nearest-neighbour ordering; routeUrl() builds Google Maps directions
   link with waypoints. Straight-line distance, not road distance.
10. FormView: admin/index.php place form (add/edit): validation, CSRF token, photo upload, prepared statements.
11. New button: add <button> in HTML + addEventListener in script.js DOMContentLoaded block.
12. Contact nav: add ['Contact','contact.html','Contact'] to pages array in buildNav(); create contact.html.
13. Explain addToPlan(id) or optimiseRoute().
14. XAMPP provides Apache + PHP + MySQL, which this version needs.
15. Future: online hosting, road-distance routing with Directions API, reviews/ratings, multi-language (Tamil/Sinhala/English),
    visitor plans saved in the database, image gallery.
Be honest: coordinates are approximate; the first submitted version was a localStorage prototype.
