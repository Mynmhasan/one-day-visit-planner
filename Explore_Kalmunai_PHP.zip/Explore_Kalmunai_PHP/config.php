<?php
// Database settings (XAMPP defaults)
const DB_HOST = 'localhost', DB_NAME = 'explore_kalmunai', DB_USER = 'root', DB_PASS = '';
session_start();
function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    }
    return $pdo;
}
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function check_csrf() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(403); exit('Invalid request token.'); }
}
function require_admin($super = false) {
    if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
    if ($super && $_SESSION['admin']['role'] !== 'super_admin') { http_response_code(403); exit('Super admin only.'); }
}
