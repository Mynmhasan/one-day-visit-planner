<?php
require '../config.php';
unset($_SESSION['admin']); session_regenerate_id(true);
header('Location: login.php');
