<?php
require '../config.php'; require_admin();
$pdo = db(); $msg = ''; $err = ''; $title = 'Place Management';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $act = $_POST['action'] ?? '';
    if ($act === 'delete') { $pdo->prepare('DELETE FROM places WHERE id=?')->execute([(int)$_POST['id']]); $msg = 'Place deleted.'; }
    if ($act === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? ''); $cat = trim($_POST['category'] ?? ''); $desc = trim($_POST['description'] ?? '');
        $loc = trim($_POST['location'] ?? ''); $lat = $_POST['lat'] ?? ''; $lng = $_POST['lng'] ?? '';
        $hours = trim($_POST['hours'] ?? '') ?: 'Verify locally before visiting'; $tips = trim($_POST['tips'] ?? '');
        $image = trim($_POST['image'] ?? '') ?: 'hero.jpg';
        if ($name === '' || $cat === '' || $loc === '' || !is_numeric($lat) || !is_numeric($lng) || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
            $err = 'Name, category, location and valid coordinates are required.';
        } else {
            if (!empty($_FILES['photo']['name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp']) && $_FILES['photo']['size'] <= 2097152 && @getimagesize($_FILES['photo']['tmp_name'])) {
                    $image = uniqid('p_') . '.' . $ext;
                    move_uploaded_file($_FILES['photo']['tmp_name'], __DIR__ . '/../images/' . $image);
                } else { $err = 'Photo must be a JPG/PNG/WEBP image under 2 MB.'; }
            }
            if (!$err) {
                $pdo->prepare('INSERT IGNORE INTO categories(name) VALUES(?)')->execute([$cat]);
                $st = $pdo->prepare('SELECT id FROM categories WHERE name=?'); $st->execute([$cat]); $cid = $st->fetchColumn();
                $v = [$name, $cid, $desc, $loc, $lat, $lng, $hours, $image, $tips];
                if ($id) { $v[] = $id; $pdo->prepare('UPDATE places SET name=?,category_id=?,description=?,location=?,lat=?,lng=?,hours=?,image=?,tips=? WHERE id=?')->execute($v); $msg = 'Place updated.'; }
                else { $pdo->prepare('INSERT INTO places(name,category_id,description,location,lat,lng,hours,image,tips) VALUES(?,?,?,?,?,?,?,?,?)')->execute($v); $msg = 'Place added.'; }
            }
        }
    }
}
$edit = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT p.*,c.name AS category FROM places p JOIN categories c ON c.id=p.category_id WHERE p.id=?'); $s->execute([(int)$_GET['edit']]); $edit = $s->fetch() ?: null;
}
$places = $pdo->query('SELECT p.id,p.name,p.lat,p.lng,c.name AS category FROM places p JOIN categories c ON c.id=p.category_id ORDER BY p.id')->fetchAll();
$cats = $pdo->query('SELECT name FROM categories ORDER BY name')->fetchAll(PDO::FETCH_COLUMN);
$f = fn($k) => e($edit[$k] ?? '');
include '_header.php';
?>
<h1 class="title">Place Management</h1>
<?php if ($msg): ?><div class="msg ok"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form class="admin-form" method="post" enctype="multipart/form-data">
<h2><?= $edit ? 'Edit place' : 'Add place' ?></h2>
<input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="save">
<input type="hidden" name="id" value="<?= $f('id') ?>"><input type="hidden" name="image" value="<?= $f('image') ?>">
<label>Place name</label><input name="name" value="<?= $f('name') ?>" required>
<label>Category (type a new one to create it)</label><input name="category" list="cats" value="<?= $f('category') ?>" required>
<datalist id="cats"><?php foreach ($cats as $c): ?><option value="<?= e($c) ?>"><?php endforeach; ?></datalist>
<label>Description</label><textarea name="description" rows="3"><?= $f('description') ?></textarea>
<div class="form-grid">
<div><label>Location / address</label><input name="location" value="<?= $f('location') ?>" required></div>
<div><label>Opening hours</label><input name="hours" value="<?= $f('hours') ?>"></div>
<div><label>Latitude</label><input name="lat" type="number" step="0.000001" value="<?= $f('lat') ?>" required></div>
<div><label>Longitude</label><input name="lng" type="number" step="0.000001" value="<?= $f('lng') ?>" required></div>
</div>
<label>Photo (JPG/PNG/WEBP, max 2 MB)</label><input type="file" name="photo" accept="image/*">
<label>Travel tips</label><textarea name="tips" rows="2"><?= $f('tips') ?></textarea>
<div class="btns"><button class="btn btn-p" type="submit">Save place</button><?php if ($edit): ?><a class="btn btn-o" href="index.php">Cancel</a><?php endif; ?></div>
</form>
<h2>Current places (<?= count($places) ?>)</h2><div class="admin-list">
<?php foreach ($places as $p): ?><div class="admin-item"><div class="item-info"><b><?= e($p['name']) ?></b><small><?= e($p['category']) ?> · <?= e($p['lat']) ?>, <?= e($p['lng']) ?></small></div>
<div class="item-actions"><a class="map-link" style="padding:9px 12px;border-radius:7px" href="?edit=<?= (int)$p['id'] ?>">Edit</a>
<form method="post" onsubmit="return confirm('Delete this place?')"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="delete" type="submit">Delete</button></form></div></div>
<?php endforeach; ?></div></section></body></html>
