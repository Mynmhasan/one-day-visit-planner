<?php
require '../config.php'; require_admin(true);
$pdo = db(); $msg = ''; $err = ''; $title = 'Admin Accounts';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $un = trim($_POST['username'] ?? ''); $pw = $_POST['password'] ?? ''; $role = $_POST['role'] ?? 'admin';
        if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $un)) $err = 'Username: 3-30 letters, numbers or underscore.';
        elseif (strlen($pw) < 8) $err = 'Password must be at least 8 characters.';
        elseif (!in_array($role, ['admin', 'super_admin'])) $err = 'Invalid role.';
        else {
            try { $pdo->prepare('INSERT INTO admins(username,password_hash,role) VALUES(?,?,?)')->execute([$un, password_hash($pw, PASSWORD_DEFAULT), $role]); $msg = 'Account created.'; }
            catch (PDOException $ex) { $err = 'That username already exists.'; }
        }
    }
    if ($act === 'delete') {
        $pdo->prepare("DELETE FROM admins WHERE id=? AND role='admin'")->execute([(int)$_POST['id']]); $msg = 'Admin removed.';
    }
}
$admins = $pdo->query('SELECT id,username,role,created_at FROM admins ORDER BY id')->fetchAll();
include '_header.php';
?>
<h1 class="title">Admin Accounts <small style="font-size:1rem">(Super admin only)</small></h1>
<?php if ($msg): ?><div class="msg ok"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form class="admin-form" method="post"><h2>Create account</h2>
<input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="add">
<div class="form-grid"><div><label>Username</label><input name="username" required></div>
<div><label>Password (min 8)</label><input name="password" type="password" required></div></div>
<label>Role</label><select name="role"><option value="admin">Admin</option><option value="super_admin">Super admin</option></select>
<div class="btns"><button class="btn btn-p" type="submit">Create</button></div></form>
<h2>Accounts</h2><div class="admin-list">
<?php foreach ($admins as $a): ?><div class="admin-item"><div class="item-info"><b><?= e($a['username']) ?></b><small><?= e($a['role']) ?> · created <?= e($a['created_at']) ?></small></div>
<?php if ($a['role'] === 'admin'): ?><form method="post" onsubmit="return confirm('Remove this admin?')"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="delete" type="submit">Remove</button></form><?php endif; ?></div>
<?php endforeach; ?></div></section></body></html>
