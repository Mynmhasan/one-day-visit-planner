<?php $u = $_SESSION['admin']; ?><!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> - Explore Kalmunai</title><link rel="stylesheet" href="../style.css"></head><body>
<nav class="nav"><a class="logo" href="../index.html"><i>📍</i>Explore <span>Kalmunai</span></a><ul>
<li><a class="link" href="index.php">Places</a></li>
<?php if ($u['role'] === 'super_admin'): ?><li><a class="link" href="admins.php">Admins</a></li><?php endif; ?>
<li><small>👤 <?= e($u['username']) ?> (<?= e($u['role']) ?>)</small></li><li><a class="link" href="logout.php">Logout</a></li></ul></nav><section>
