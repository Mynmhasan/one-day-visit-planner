<?php
require '../config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    try {
        $st = db()->prepare('SELECT * FROM admins WHERE username=?'); $st->execute([trim($_POST['username'] ?? '')]);
        $a = $st->fetch();
        if ($a && password_verify($_POST['password'] ?? '', $a['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin'] = ['id' => $a['id'], 'username' => $a['username'], 'role' => $a['role']];
            header('Location: index.php'); exit;
        }
        $err = 'Invalid username or password.';
    } catch (Throwable $ex) { $err = 'Database unavailable. Run setup.php first.'; }
}
?><!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login - Explore Kalmunai</title><link rel="stylesheet" href="../style.css"></head><body>
<nav class="nav"><a class="logo" href="../index.html"><i>📍</i>Explore <span>Kalmunai</span></a></nav>
<section><div class="box admin-box"><h2>Administrator Login</h2>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
<label for="u">Username</label><input id="u" name="username" required>
<label for="p">Password</label><input id="p" name="password" type="password" required>
<button class="btn btn-p full" type="submit">Sign in</button>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?></form></div></section></body></html>
