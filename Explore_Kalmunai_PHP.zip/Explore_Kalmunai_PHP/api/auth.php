<?php
// Visitor authentication API: me | login | register | logout
require __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
$action = $_GET['action'] ?? '';
$in = json_decode(file_get_contents('php://input'), true) ?: [];
try {
    if ($action === 'me') { echo json_encode(['user' => $_SESSION['user'] ?? null]); }
    elseif ($action === 'logout') { unset($_SESSION['user']); echo json_encode(['ok' => true]); }
    elseif ($action === 'register') {
        $name = trim($in['name'] ?? ''); $email = strtolower(trim($in['email'] ?? '')); $phone = trim($in['phone'] ?? ''); $pw = $in['password'] ?? '';
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) exit(json_encode(['error' => 'Enter a valid name and email.']));
        if (!preg_match('/^\+?[0-9 ()-]{9,20}$/', $phone)) exit(json_encode(['error' => 'Enter a valid phone number.']));
        if (strlen($pw) < 6) exit(json_encode(['error' => 'Password must be at least 6 characters.']));
        $st = db()->prepare('SELECT id FROM users WHERE email=?'); $st->execute([$email]);
        if ($st->fetch()) exit(json_encode(['error' => 'This email is already registered.']));
        db()->prepare('INSERT INTO users(name,email,phone,password_hash) VALUES(?,?,?,?)')->execute([$name, $email, $phone, password_hash($pw, PASSWORD_DEFAULT)]);
        echo json_encode(['ok' => true]);
    }
    elseif ($action === 'login') {
        $u = trim($in['username'] ?? '');
        $st = db()->prepare('SELECT * FROM users WHERE email=? OR name=? LIMIT 1'); $st->execute([strtolower($u), $u]);
        $row = $st->fetch();
        if ($row && password_verify($in['password'] ?? '', $row['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $row['id'], 'name' => $row['name']];
            echo json_encode(['ok' => true]);
        } else echo json_encode(['error' => 'Invalid username/email or password.']);
    }
    else echo json_encode(['error' => 'Unknown action.']);
} catch (Throwable $ex) { http_response_code(500); echo json_encode(['error' => 'Server error. Run setup.php first.']); }
