<?php
// REST-style JSON API: returns all places with their category names.
require __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
try {
    $rows = db()->query('SELECT p.id,p.name,c.name AS category,p.description,p.location,p.lat,p.lng,p.hours,p.image,p.tips
                         FROM places p JOIN categories c ON c.id=p.category_id ORDER BY p.id')->fetchAll();
    foreach ($rows as &$r) { $r['id'] = (string)$r['id']; $r['lat'] = (float)$r['lat']; $r['lng'] = (float)$r['lng']; }
    echo json_encode(['places' => $rows]);
} catch (Throwable $ex) {
    http_response_code(500);
    echo json_encode(['places' => [], 'error' => 'Database unavailable. Run setup.php first.']);
}
