# Explore Kalmunai – PHP/MySQL version

## Folder contents
- index.html, places.html, planner.html, login.html, register.html, about.html – public pages
- style.css, script.js, images/ – styling, front-end logic, pictures
- api/places.php, api/auth.php – JSON API (places, visitor login/register)
- admin/ – admin panel (index.php = places, admins.php = super admin only, login.php, logout.php)
- config.php – database connection (PDO) and helper functions
- explore_kalmunai.sql – database (tables + 10 places + 2 admin accounts)
- setup.php – optional automatic installer (alternative to importing the SQL)

## Setup (XAMPP)
1. Copy this folder to C:\xampp\htdocs\  (keep the name Explore_Kalmunai_PHP)
2. Start Apache and MySQL in XAMPP.
3. phpMyAdmin -> New -> database name: explore_kalmunai (utf8mb4_general_ci) -> Create.
4. Select explore_kalmunai -> Import -> choose explore_kalmunai.sql -> Import.
5. Test: http://localhost/Explore_Kalmunai_PHP/api/places.php  (should show JSON)
6. Website: http://localhost/Explore_Kalmunai_PHP/index.html
7. Admin:   http://localhost/Explore_Kalmunai_PHP/admin/login.php

## Accounts
- Super admin: superadmin / SuperAdmin@123
- Admin: admin / Admin@123
If MySQL root has a password, set it in config.php (DB_PASS).

## Where is what (viva)
- DB connection: config.php -> db()
- Frontend -> backend: script.js -> loadPlaces() uses fetch('api/places.php')
- Reusable components: buildNav(), buildFooter(), placeCard()
- Google Maps: mapsUrl() (link), "Show on map" iframe embed (places.html)
- GPS: script.js -> useMyLocation() (navigator.geolocation)
- Route logic: script.js -> dist() (haversine), optimiseRoute() (nearest neighbour), routeUrl()
- Form (FormView): admin/index.php place form; login.html / register.html forms
- Roles: admin = manage places; super_admin = also manage admin accounts (admin/admins.php)
- Security: password_hash/password_verify, PDO prepared statements, CSRF token, session checks, output escaping (e())

## Honest note for the examiner
The submitted version was a front-end prototype (HTML/CSS/JS + localStorage). This version adds the
PHP/MySQL backend that was listed as future work in the report.
